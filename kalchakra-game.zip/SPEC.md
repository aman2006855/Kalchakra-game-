# 🎮 KALCHAKRA - The Time Weaver's Paradox

## 1. Concept & Vision

**KALCHAKRA** (कालचक्र - The Wheel of Time) is a mythological action-puzzle game where players control **TIME WEavers** - ancient beings who can manipulate the 4 dimensions of time: Past, Present, Future, and Eternal Now.

**Core Unique Selling Point:** No two playthroughs are the same. The game world changes based on your temporal choices. What you break in the past affects the future. Your future self can help (or sabotage) your past self.

**Story:** The cosmic wheel of time has shattered. The player is the last Time Weaver who must journey through 7 mythological realms (inspired by Indian/Hindu cosmology) to collect the fragments of the Kalchakra and restore balance to existence.

**Tagline:** "Koi bhi decision forever badalta hai... time ko, destiny ko, aur tumhe bhi."

---

## 2. Design Language

### Aesthetic Direction
- **Visual Style:** Mystical Indian-Art- deco fusion. Think ancient temple carvings meeting Art Deco geometry.
- **Dark cosmic backgrounds with golden mandala patterns, glowing runes, and particle effects.**
- **Color Palette:**
  - Primary: `#FFD700` (Divine Gold)
  - Secondary: `#1a0a2e` (Cosmic Purple-Black)
  - Accent: `#ff3366` (Temporal Red - for glitches/danger)
  - Energy: `#00ffcc` (Ethereal Cyan)
  - Background: `#0d0015` (Void)
  - Text: `#e8d5b7` (Aged Parchment)

### Typography
- **Title/Headers:** "Cinzel Decorative" - ornate, ancient feel
- **Body:** "Rajdhani" - futuristic yet Indian
- **UI Numbers:** "Orbitron" - for timers and scores

### Spatial System
- 8px base unit grid
- Circular/radial layouts for menus (echoing the wheel motif)
- Layered parallax backgrounds for depth

### Motion Philosophy
- **Time Manipulation:** Slow-motion effects, time-freeze visual ripples
- **UI:** Elements spin in like a wheel, golden particle trails
- **Feedback:** Screen shake on impact, chromatic aberration on damage
- **Transitions:** Circular wipe (wheel opening/closing)

### Visual Assets
- SVG-based mandala patterns
- Canvas-based particle systems
- Procedural golden dust trails

---

## 3. Layout & Structure

### Game Screens

1. **TITLE SCREEN**
   - Animated Kalchakra (wheel) logo rotating
   - "PRESS TO WEAVE TIME" pulsing text
   - Mystical background with floating particles

2. **MAIN MENU**
   - Circular wheel menu with 5 options:
     - ▶ PLAY (Journey)
     - ⏱ TIMELINE (High Scores)
     - ⚙ SANSTHAN (Settings)
     - 📖 VEDIC LORE (Story/Encyclopedia)
     - 🚪 EXIT (Return to Void)

3. **GAMEPLAY SCREEN**
   - Central play area (canvas)
   - Top HUD: Health (golden life threads), Temporal Energy (cyan bar), Score
   - Bottom: Current realm name, Time distortion meter

4. **PAUSE MENU**
   - Time frozen with visual frost/glitch effect
   - Options: Resume, Restart, Settings, Quit

5. **GAME OVER**
   - Wheel shattering animation
   - Stats display with "Try Again" or "Main Menu"

### Responsive Strategy
- Canvas scales to fit viewport (maintains aspect ratio)
- Touch controls for mobile (drag to move, tap to shoot)
- Keyboard/mouse for desktop

---

## 4. Features & Interactions

### Core Gameplay Loop

**Player Controls:**
- **Movement:** WASD/Arrow keys or drag on mobile
- **Time Powers:** 
  - SPACE: Freeze time (slows enemies, costs temporal energy)
  - Q: Rewind 3 seconds (limited uses per level)
  - E: Fast-forward (speed boost, enemies become vulnerable)
  - R: Echo (summon shadow clone of your past position)

**Game Mechanics:**

1. **Temporal Energy System**
   - Blue/cyan bar that depletes with power use
   - Regenerates slowly over time
   - Collect golden orbs to restore

2. **Paradox Mechanics**
   - Your actions create "time echoes"
   - Echoes of yourself appear showing past positions
   - Enemies can also have echoes (harder)
   - Collect YOUR echoes for bonus points
   - Avoid ENEMY echoes (they damage you)

3. **Realm Progression**
   - 7 Realms, each with unique mechanics:
     1. **Satya Loka** (Realm of Truth) - Tutorial realm
     2. **Tapta Loka** (Realm of Fire) - Moving platforms, heat damage
     3. **Jala Loka** (Realm of Water) - Fluid physics, currents
     4. **Vayu Loka** (Realm of Wind) - Pushing winds, flying enemies
     5. **Bhumi Loka** (Realm of Earth) - Quakes, terrain manipulation
     6. **Antariksha Loka** (Realm of Space) - Zero gravity, teleports
     7. **Mahakaal Loka** (Realm of Time) - Final boss, all mechanics

4. **Enemy Types**
   - **Kala Asura:** Basic temporal shadow creatures
   - **Vritra:** Snake-like time serpents (boss minion)
   - **Dhvaja:** Shielded archers
   - **Chaya:** Shadow duplicates of player
   - **Boss: Mahakaal** - The Lord of Time himself

5. **Power-ups (Cosmic Fragments)**
   - 🕐 **Chrono Orb:** Slows nearby enemies
   - 🔄 **Loop Crystal:** Creates a time loop (extra life)
   - ⚡ **Speed Essence:** Temporary time acceleration
   - 🛡 **Aegis Shard:** Temporal shield
   - 🌟 **Divine Light:** Massive area damage

### Scoring System
- Enemies defeated: 100 × combo multiplier
- Echoes collected: 500 points each
- Time powers used efficiently: Bonus multiplier
- Realm completion: 10,000 + time bonus
- No-damage realm: 3× multiplier

### Edge Cases
- **No Temporal Energy:** Powers disabled, must collect orbs
- **Health Zero:** Game over, option to use continue (costs score)
- **Paradox Overflow:** Too many echoes = visual distortion, then death
- **Level Complete:** Show stats, brief story cutscene, next realm

---

## 5. Component Inventory

### HUD Components

**Health Display (Life Threads)**
- 5 golden threads representing health
- Damaged threads turn grey and break
- States: Full, Damaged, Critical (1 left - red glow), Empty

**Temporal Energy Bar**
- Cyan glowing bar with liquid animation
- States: Full (bright), Depleting (animated drain), Empty (dim), Recharging (sparkle effect)

**Score Display**
- Ornate frame with number counter
- Animated number roll on increase
- Golden particle burst on milestone

**Realm Indicator**
- Sanskrit name with English translation
- Circular progress showing realm completion

**Combo Meter**
- Multiplier badge that grows with consecutive kills
- States: Inactive, Active (glowing), Max (pulsing), Fading

### Interactive Components

**Menu Wheel**
- Circular selection interface
- Hover: Segment glows, spins slightly
- Selected: Expands, particles emit
- Click: Wheel spin animation to selection

**Pause Button**
- Ornate mandala design
- Hover: Rotates slowly
- Click: Ripple freeze effect

**Settings Sliders**
- Golden track with jewel handles
- Draggable with haptic tick marks

### Game Entities

**Player (Time Weaver)**
- Robed figure with glowing eyes
- Cape that flows against time
- Trail of golden particles when moving
- States: Idle (subtle float), Moving (lean + trail), Using Power (glow + effect), Damaged (flash + shake), Dead (dissolve)

**Enemies**
- Shadowy dark forms with red accents
- Temporal distortion aura
- States: Spawning (fade in), Active, Damaged (flash), Dying (shatter)

**Projectiles**
- Player: Golden arrows of light
- Enemies: Red temporal shards
- Effects: Trail particles, impact explosion

### Modal Dialogs

**Story Interstitial**
- Parchment-style background
- Sanskrit quote + English translation
- "Continue" button with glow

**Game Over Screen**
- Shattered wheel centerpiece
- Stats: Score, Realms Completed, Enemies Defeated
- Buttons: Try Again, Main Menu

---

## 6. Technical Approach

### Architecture
- **Single HTML file** with embedded CSS and JavaScript
- **Canvas-based rendering** for game graphics
- **RequestAnimationFrame** for game loop (60 FPS target)
- **State Machine** for game flow management

### Core Systems

```
GameState = {
  TITLE,
  MENU,
  PLAYING,
  PAUSED,
  GAME_OVER,
  REALM_TRANSITION,
  CUTSCENE
}
```

### Classes/Modules

1. **GameEngine** - Main loop, state management, timing
2. **Renderer** - Canvas drawing, effects, particles
3. **InputManager** - Keyboard, mouse, touch handling
4. **EntityManager** - Player, enemies, projectiles, pickups
5. **CollisionSystem** - Hit detection, spatial partitioning
6. **AudioManager** - Sound effects (Web Audio API), music
7. **ParticleSystem** - Visual effects, trails
8. **UIEngine** - Menus, HUD, modals
9. **TemporalSystem** - Time manipulation logic
10. **RealmManager** - Level generation, progression

### Data Model

```javascript
Player = {
  x, y, health, temporalEnergy,
  positionHistory: [], // For rewind
  score: 0, combo: 0
}

Enemy = {
  type, x, y, health, behavior,
  echoPositions: [], // Past positions for paradox
  temporalState: 'normal' | 'slowed' | 'fast'
}

Realm = {
  id, name, sanskritName,
  enemies: [], obstacles: [],
  powerUps: [], collectibles: [],
  boss: null | Enemy
}

GameData = {
  currentRealm: 1,
  totalScore: 0,
  highScores: [],
  settings: { volume, difficulty, controls }
}
```

### Performance Targets
- 60 FPS on modern browsers
- < 16ms frame time
- Efficient particle pooling (max 200 particles)
- Object pooling for projectiles/enemies

### Storage
- LocalStorage for high scores and settings
- No server/backend required

---

## 7. Audio Design

### Sound Effects (Web Audio API synthesized)
- **Time Freeze:** Low whoosh + crystalline chime
- **Rewind:** Reverse tape warble effect
- **Fast Forward:** Rising pitch sweep
- **Enemy Hit:** Thud + temporal distortion crack
- **Player Damage:** Deep resonant bell
- **Power Up:** Ascending ethereal notes
- **Menu Select:** Soft gong strike
- **Realm Complete:** Triumphant drums + bells

### Music
- Procedurally generated ambient drone using Web Audio API
- Each realm has unique frequency base:
  - Satya: 432 Hz (truth/healing)
  - Tapta: 528 Hz (fire/energy)
  - etc.

---

## 8. Polish Details

- **Loading Screen:** Animated wheel spinning
- **Favicon:** Golden wheel icon
- **Cursor:** Custom crosshair in gameplay
- **Selection Color:** Gold highlight
- **Scrollbar:** Dark with gold thumb
- **Focus States:** Golden glow outline
- **Custom Scrollbar:** Thin, ornate
- **Particle Density:** Adjusts based on device performance

---

## 9. Scope for MVP (This Implementation)

For the initial complete game, implementing:
- ✅ Title screen with animation
- ✅ Main menu with wheel selector
- ✅ Gameplay in 2 realms (Satya + Tapta)
- ✅ Basic enemies (Kala Asura, Dhvaja)
- ✅ 3 time powers (Freeze, Rewind, Fast Forward)
- ✅ Health and Energy system
- ✅ Score and combo system
- ✅ Pause functionality
- ✅ Game Over and restart
- ✅ Sound effects (synthesized)
- ✅ Particle effects
- ✅ Mobile touch controls

Future expansion:
- More realms
- More enemy types
- Boss fights
- Save system
- Multiplayer echo battles
